#### Outdoor toys Search
###### Detailed Description:
- Launch any browser and open the site �http://www.ebay.com� 
- Maximize the window 
- Locate �advanced� Search button and click on it. 
- Enter "outdoor toys" in the Enter keywords or item number textbox and select �Any words, any order� in the listbox next the textbox
- Select the checkbox �New� under Condition
- Under Location, Select From preferred locations as �Worldwide�
- Click on �Search� button 
- Verify the category changed to �Outdoor Toys & Structures� in category dropdown in search box
- Get the href values of all the links in the search result page
- Verify if �href� value of any item�s link matches with the text �portable� then Click on that item's link and display name of that item on console
- Close Browser

###### Console Output:
```
Category changed to Outdoor Toys & Structures
Found all the href values
Verified the link contains "Portable" text
Clicked on the link contains "Portable" text
Screenshot captured successfully
Script completed successfully
```
